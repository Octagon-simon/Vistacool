<html><head>
     

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
  
  <script src="js/jquery-3.3.1.slim.min.js"></script>
  <link rel="stylesheet" href="fontawesome4/css/font-awesome.min.css">
  <link rel="stylesheet" href="bootstrap/4/css/bootstrap.min.css">
  <link rel="stylesheet" href="dmxAppConnect/dmxValidator/dmxValidator.css">
  <script src="dmxAppConnect/dmxValidator/dmxValidator.js" defer=""></script>
  </head>
  <body is="dmx-app" id="paystack">
    <div class="container">
   <div align="Center">
        <button class="btn btn-warning text-center" data-toggle="modal" data-target="#modal_payment"><img src="assets/images/Paystack%20Logo.png" width="30" height="30" class="img-fluid"> Pay with Paystack</button>
      </div>
    </div>
    <div class="modal" id="modal_payment" is="dmx-bs4-modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Fill in the details</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <h4 class="text-center"><img src="assets/images/Paystack%20Logo.png" width="30" height="30" class="img-fluid"> Pay with Paystack</h4>
            <form id="paymentForm">
              <div class="form-group">
              <label>Your Email Address&nbsp; *</label>
                <input id="email-address" name="email-address" type="text" class="form-control" placeholder="Email Address" required="">
              </div>
              <div class="form-group">
                <label>Enter Amount&nbsp; *</label>
                <input id="amount" name="amount" type="tel" class="form-control" placeholder="Amount you are paying" required="">
              </div>
              <div class="form-group">
                <label>Your First Name&nbsp; *</label>
                <input id="first-name" name="first-name" type="text" class="form-control" placeholder="First Name" required="">
              </div>
              <div class="form-group">
                <label>Your Last Name&nbsp; *</label>
                <input id="last-name" name="last-name" type="text" class="form-control" placeholder="Last Name" required="">
              </div>
          
      
          <div class="modal-footer form-submit">
            <button type="submit" onclick="payWithPaystack()" class="btn btn-block btn-success"><i class="fa fa-money"></i>&nbsp; Authorize Payment</button>
          </div>
        </form>
        </div>
      </div>
    </div>
    <script src="https://js.paystack.co/v1/inline.js"></script> 
<script src="app.js"></script> 
    <script src="bootstrap/4/js/popper.min.js"></script>
    <script src="bootstrap/4/js/bootstrap.min.js"></script>
  </body></html>
